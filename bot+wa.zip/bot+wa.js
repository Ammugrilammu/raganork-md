link bot
https://www.mediafire.com/file/2rfd4h9tfxme3ss/v-10.7z/file

link wa bussines clone
https://www.mediafire.com/file/e1m6hury04q8ank/WhatsApp+Business_2.22.20.79_jo.7z/file

link wa bussines unclone
https://www.mediafire.com/file/5lw0t0vi52ifule/WhatsApp+Business_2.22.20.79.7z/file